#!/bin/bash
ansible-playbook -i inventory.yaml configure.yml
